#include <stdio.h>

#include "text.h"

void myText(void) {
  printf("Learn about makefiles!\n");
  return;
}