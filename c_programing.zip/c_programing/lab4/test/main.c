#include "text.h"

int main() {
  myText();
  return 0;
}