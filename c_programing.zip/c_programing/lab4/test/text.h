void myText(void);
